# 小步清单 · CDS 新人实验室

给产品经理与业务同事的最小真实项目：新增任务、标记完成、刷新与重新部署后保留。

## 本地练习

需要 Node.js 22；无第三方运行依赖。

```sh
node server.mjs
node --test test.mjs
```

## CDS 部署

将仓库接入自己的 CDS 项目。根目录 `cds-compose.yml` 是部署合同：一个 Node.js 服务、3000 端口、`/health` 探活、`/` 用户入口以及 `/data` 持久化目录。默认源码配置用于理解运行条件；Agent 部署应选择 express 极速版。工作流名称固定为 Branch Image，保存在 `.github/workflows/branch-image.yml`，供 CDS 识别完成事件。GitHub Actions 先运行真实 HTTP 回归测试，成功后构建并推送当前完整提交 SHA 对应的不可变镜像；CDS 收到工作流成功事件后运行该产物。

获取预览入口必须使用 `cdscli --human preview-url`，不要根据分支名拼域名。打开实际预览，新增任务、标记完成、刷新，再重新部署同一分支确认任务仍在。

## 教学边界

这是共享练习区，没有账号或权限隔离，只填写演示数据。同一项目的不同分支若沿用同一个数据卷会共享任务；复制案例时修改卷名，只在本案例 main 分支验证持久化。不是正式业务待办系统。工作区 `.cds` 凭据禁止进入 Git 与源码下载包。
