import http from 'node:http';
import {readFile,writeFile,mkdir,rename} from 'node:fs/promises';
import path from 'node:path';
import {fileURLToPath} from 'node:url';
import {randomUUID} from 'node:crypto';
const root=path.dirname(fileURLToPath(import.meta.url));
export async function createApp({dataDir=process.env.DATA_DIR||path.join(root,'data')}={}) {
 await mkdir(dataDir,{recursive:true});const file=path.join(dataDir,'tasks.json');
 let tasks=[];try{tasks=JSON.parse(await readFile(file,'utf8'));if(!Array.isArray(tasks))throw Error('Invalid data');}catch(e){if(e.code!=='ENOENT')throw e;}
 let queue=Promise.resolve();
 const mutate=fn=>{const next=queue.then(async()=>{const draft=structuredClone(tasks);const result=fn(draft);await writeFile(file+'.tmp',JSON.stringify(draft),'utf8');await rename(file+'.tmp',file);tasks=draft;return result;});queue=next.catch(()=>{});return next;};
 const json=(res,status,body)=>{res.writeHead(status,{'Content-Type':'application/json; charset=utf-8','Cache-Control':'no-store','X-Content-Type-Options':'nosniff'});res.end(JSON.stringify(body));};
 const body=async req=>{let buf='';for await(const part of req){buf+=part;if(Buffer.byteLength(buf)>8192){const e=Error('内容太长，请缩短后重试');e.status=413;throw e;}}try{return JSON.parse(buf);}catch{const e=Error('内容无法读取，请刷新后重试');e.status=400;throw e;}};
 const server=http.createServer(async(req,res)=>{try{
  const url=new URL(req.url,'http://localhost');const p=url.pathname;
  if(req.method==='GET'&&p==='/health')return json(res,200,{status:'ok',app:'small-steps'});
  if(req.method==='GET'&&p==='/api/tasks') {await queue;return json(res,200,{tasks});}
  if(req.method==='POST'&&p==='/api/tasks'){
   const b=await body(req);if(!b||typeof b.title!=='string'||!b.title.trim()||b.title.trim().length>80)return json(res,400,{error:'请填写 1–80 字的任务标题'});
   return json(res,201,await mutate(d=>{const task={id:randomUUID(),title:b.title.trim(),done:false};d.unshift(task);return task;}));
  }
  if(req.method==='PATCH'&&p.startsWith('/api/tasks/')){
   const b=await body(req);if(!b||typeof b.done!=='boolean')return json(res,400,{error:'请明确选择完成或未完成'});
   const task=await mutate(d=>{const t=d.find(x=>x.id===p.split('/').at(-1));if(!t){const e=Error('任务已不存在，请刷新列表');e.status=404;throw e;}t.done=b.done;return t;});return json(res,200,task);
  }
  if(req.method==='GET'&&(p==='/'||p==='/index.html')) {res.writeHead(200,{'Content-Type':'text/html; charset=utf-8','X-Content-Type-Options':'nosniff'});return res.end(await readFile(path.join(root,'public/index.html')));}
  return json(res,404,{error:'页面不存在，请返回首页'});
 }catch(e){return json(res,e.status||500,{error:e.status?e.message:'暂时无法保存，请稍后重试'});}});
 return server;
}
if(process.argv[1]&&path.resolve(process.argv[1])===fileURLToPath(import.meta.url)){
 const server=await createApp();const port=Number(process.env.PORT||8841);server.listen(port,process.env.HOST||'127.0.0.1',()=>console.log(`小步清单：http://${process.env.HOST||'127.0.0.1'}:${server.address().port}`));
}
