# 小步清单 · 首次接入与恢复演练

新人实验室的隔离演练副本。原来的教学站继续可用，本仓库只使用演示数据。

版本 A 作为回滚基线；版本 B 提供可见变化。显式故障文件 .cds-ci-failure-drill 只让 CI 门禁失败，不破坏应用代码；删除后恢复构建。工作流先跑 HTTP 测试，再检查故障开关，通过才发布不可变镜像。

CDS 使用 express 模式与独立数据卷；从 preview-url 获取真实地址。验收比较实际运行镜像的完整提交号、部署运行 ID、版本 ID 和同一任务 ID，不能只看分支标题。

运行 node --test test.mjs 验证 HTTP 业务；node server.mjs 启动本地练习。项目凭据只在 .cds/credentials.json，不入仓库。没有账号隔离，只填写练习数据。

## 三个案例与主项目

这是独立恢复案例 cds-small-steps-closure-lab。基础练习在 cds-small-steps-lab；授权专项在 cds-onboarding-receipt-lab，只验证权限，不部署应用。CDS 平台、教程、动画和录屏保存在 prd_agent。

2026-10-14 复验以 A 为回滚目标，E 显式失败，F 恢复。镜像的 org.opencontainers.image.revision 必须等于 github.sha，否则 CI 成功仍会被 CDS 保留旧服务并等待正确产物。仅修改工作流不会触发应用发布；本次可见 F 应用变更触发完整自动发布。

复制到自己的仓库时让 Agent 同时改工作流和 CDS 的镜像仓库地址，并为每个项目及分支指定独立卷名。本案例卷名不可复用。下载包不含项目凭据；按自己的项目首次批准，后续使用本地有效项目凭据静默复用。

## 旧回滚产物的身份复核

旧 A 镜像没有 OCI 提交身份，不可直接作为新版验收通过证据。手动工作流 Rollback Baseline Image 固定检出 A 的完整提交、验证 HTTP 业务，另建 rollback-a-verified-20261014 镜像；不覆盖旧 sha-A 镜像。CDS 重新核验后生成新的 A 部署版本，回滚时选日期 2026-10-14 的已核验 A。源码包包含最新流程文件，应用源码仍与 F 的可见发布内容一致。
