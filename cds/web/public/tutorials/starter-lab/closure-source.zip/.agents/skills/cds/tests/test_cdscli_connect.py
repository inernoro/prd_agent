"""CDS 安全接入：页面批准、项目凭据与密钥不出 stdout。"""

import io
import json
import os
import subprocess
import sys
from pathlib import Path

import pytest

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "cli"))

import cdscli  # noqa: E402


@pytest.fixture()
def workspace(tmp_path, monkeypatch):
    subprocess.run(["git", "init", "-q", str(tmp_path)], check=True)
    monkeypatch.chdir(tmp_path)
    for key in ("CDS_HOST", "CDS_PROJECT_ID", "CDS_PROJECT_KEY", "AI_ACCESS_KEY"):
        monkeypatch.delenv(key, raising=False)
    cdscli._TRACE_ID = "testtrace"
    cdscli._HUMAN = False
    return tmp_path


def run_command(argv: list[str]) -> tuple[int, str]:
    buf = io.StringIO()
    real_stdout = sys.stdout
    sys.stdout = buf
    code = 0
    try:
        cdscli.main(argv)
    except SystemExit as exc:
        code = exc.code if isinstance(exc.code, int) else 1
    finally:
        sys.stdout = real_stdout
    return code, buf.getvalue()


def test_connect_existing_project_saves_local_credential_without_printing_secret(workspace, monkeypatch):
    secret = "cdsp_demo_secret-never-print"
    calls: list[tuple[str, str, int]] = []

    def fake_request(method, path, body=None, timeout=15, extra_headers=None,
                     fatal_network_errors=True):
        calls.append((method, path, timeout))
        if method == "POST":
            return 201, {"requestId": "req1", "pollToken": "poll1", "status": "pending"}, {}
        if path.endswith("/req1"):
            assert extra_headers == {"X-Poll-Token": "poll1"}
            return 200, {"status": "approved", "authorizationKey": secret}, {}
        return 200, {"id": "proj-a"}, {}

    monkeypatch.setattr(cdscli, "_request", fake_request)
    monkeypatch.setattr(cdscli.time, "sleep", lambda _seconds: None)

    code, output = run_command([
        "connect", "--host", "https://cds.example", "--project", "proj-a",
        "--agent", "Codex", "--interval", "1",
    ])

    assert code == 0
    assert secret not in output
    saved = json.loads((workspace / ".cds" / "credentials.json").read_text())
    assert saved == {
        "version": 1,
        "host": "https://cds.example",
        "projectId": "proj-a",
        "projectKey": secret,
    }
    assert oct((workspace / ".cds" / "credentials.json").stat().st_mode & 0o777) == "0o600"
    exclude = (workspace / ".git" / "info" / "exclude").read_text()
    assert "/.cds/credentials.json" in exclude
    assert calls == [
        ("POST", "/api/projects/proj-a/access-requests", 30),
        ("GET", "/api/projects/proj-a/access-requests/req1", 10),
        ("GET", "/api/projects/proj-a", 10),
    ]


def test_connect_slug_saves_resolved_project_id(workspace, monkeypatch):
    secret = "cdsp_resolved_secret-never-print"
    calls: list[tuple[str, str]] = []

    def fake_request(method, path, body=None, timeout=15, extra_headers=None,
                     fatal_network_errors=True):
        calls.append((method, path))
        if method == "POST":
            return 201, {
                "requestId": "req-slug",
                "pollToken": "poll-slug",
                "status": "pending",
                "projectId": "project-real-id",
            }, {}
        if path.endswith("/req-slug"):
            return 200, {"status": "approved", "authorizationKey": secret}, {}
        return 200, {"id": "project-real-id"}, {}

    monkeypatch.setattr(cdscli, "_request", fake_request)
    monkeypatch.setattr(cdscli.time, "sleep", lambda _seconds: None)

    code, output = run_command([
        "connect", "--host", "https://cds.example", "--project", "project-slug",
        "--agent", "Codex", "--interval", "1",
    ])

    assert code == 0
    assert secret not in output
    saved = json.loads((workspace / ".cds" / "credentials.json").read_text())
    assert saved["projectId"] == "project-real-id"
    assert calls == [
        ("POST", "/api/projects/project-slug/access-requests"),
        ("GET", "/api/projects/project-slug/access-requests/req-slug"),
        ("GET", "/api/projects/project-real-id"),
    ]


def test_connect_new_project_infers_origin_and_creates_once(workspace, monkeypatch):
    subprocess.run(["git", "remote", "add", "origin", "git@github.com:example/demo.git"], check=True)
    def fake_request(method, path, body=None, **kwargs):
        if method == "POST" and path == "/api/bootstrap-access-requests":
            assert body["requestedProject"] == {"name": "demo", "repository": "git@github.com:example/demo.git"}
            return 201, {"requestId": "r", "pollToken": "poll"}, {}
        if path == "/api/bootstrap-access-requests/r":
            return 200, {"status": "approved", "authorizationKey": "cdsg_secret"}, {}
        if method == "POST" and path == "/api/projects":
            assert body["gitRepoUrl"] == "git@github.com:example/demo.git"
            return 201, {"project": {"id": "proj-demo"}, "issuedProjectKey": {"plaintext": "cdsp_secret"}}, {}
        return 200, {"id": "proj-demo"}, {}
    monkeypatch.setattr(cdscli, "_request", fake_request)
    code, output = run_command(["connect", "--host", "cds.example", "--new-project", "--create-project", "demo"])
    assert code == 0, output
    saved = json.loads((workspace / ".cds/credentials.json").read_text())
    assert saved["projectKey"] == "cdsp_secret" and "bootstrapKey" not in saved
    assert "cdsp_secret" not in output and "cdsg_secret" not in output


@pytest.mark.parametrize("loss", [True, False])
def test_same_new_project_command_recovers_original_project(workspace, monkeypatch, loss):
    subprocess.run(["git", "remote", "add", "origin", "https://github.com/example/demo.git"], check=True)
    cdscli._save_local_credentials(host="https://cds.example", project_id="proj-demo", project_key="cdsp_old")
    if loss:
        (workspace / ".cds/credentials.json").unlink()
    calls = []
    monkeypatch.setattr(cdscli, "_load_user_credential", lambda host: "")
    def fake_request(method, path, body=None, extra_headers=None, **kwargs):
        calls.append((method, path))
        if path.endswith("/access-status"):
            return 200, {"state": "credential-unusable"}, {}
        if path == "/api/projects/proj-demo" and extra_headers:
            return 401, {"error": "unauthorized"}, {}
        if method == "POST":
            assert path == "/api/projects/proj-demo/access-requests"
            return 201, {"requestId": "r", "pollToken": "poll", "projectId": "proj-demo"}, {}
        if path.endswith("/access-requests/r"):
            return 200, {"status": "approved", "authorizationKey": "cdsp_new"}, {}
        return 200, {"id": "proj-demo"}, {}
    monkeypatch.setattr(cdscli, "_request", fake_request)
    code, output = run_command(["connect", "--host", "cds.example", "--new-project", "--create-project", "demo"])
    assert code == 0, output
    assert all(path != "/api/projects" and "bootstrap" not in path for _, path in calls)
    assert json.loads((workspace / ".cds/credentials.json").read_text())["projectKey"] == "cdsp_new"
    assert "cdsp_old" not in output and "cdsp_new" not in output
    assert oct((workspace / ".cds/credentials.json").stat().st_mode & 0o777) == "0o600"


def test_valid_connect_is_reused_and_network_failure_never_creates_request(workspace, monkeypatch):
    cdscli._save_local_credentials(host="https://cds.example", project_id="p", project_key="cdsp_valid")
    for status in [200, 503]:
        calls = []
        def fake_request(method, path, **kwargs):
            calls.append((method, path))
            return status, {"id": "p"}, {}
        monkeypatch.setattr(cdscli, "_request", fake_request)
        code, output = run_command(["connect", "--host", "cds.example", "--project", "p"])
        assert code == (0 if status == 200 else 2)
        assert calls == [("GET", "/api/projects/p")]
        assert "cdsp_valid" not in output


@pytest.mark.parametrize("blocked", ["account-disabled", "project-access-revoked", "access-update-pending"])
@pytest.mark.parametrize("loss", [False, True])
def test_original_command_waits_for_admin_then_resumes_without_new_approval(workspace, monkeypatch, blocked, loss):
    cdscli._save_local_credentials(host="https://cds.example", project_id="p", project_key="cdsp_original")
    path = workspace / ".cds/credentials.json"
    before = path.read_bytes()
    if loss:
        path.unlink()
    monkeypatch.setattr(cdscli, "_load_user_credential", lambda host: "cdsu_original")
    states = iter([blocked, blocked, "ready"])
    calls = []
    project_reads = 0

    def fake_request(method, url, body=None, extra_headers=None, **kwargs):
        nonlocal project_reads
        calls.append((method, url))
        if url.endswith("/access-status"):
            assert extra_headers == {"x-ai-access-key": "cdsu_original" if loss else "cdsp_original"}
            assert not path.exists() if loss else path.read_bytes() == before
            return 200, {"state": next(states), "message": "等待管理员恢复原访问"}, {}
        if url == "/api/identity/project-credentials":
            assert loss and body == {"projectId": "p"}
            return 201, {"plaintext": "cdsp_recovered"}, {}
        assert method == "GET" and url == "/api/projects/p"
        project_reads += 1
        return (401 if project_reads == 1 else 200), {"id": "p"}, {}

    monkeypatch.setattr(cdscli, "_request", fake_request)
    monkeypatch.setattr(cdscli.time, "sleep", lambda _: None)
    code, output = run_command(["connect", "--host", "cds.example", "--project", "p"])
    assert code == 0, output
    assert not any("access-requests" in url or "bootstrap" in url for _, url in calls)
    assert sum(method == "POST" for method, _ in calls) == int(loss)
    assert json.loads(path.read_text())["projectKey"] == ("cdsp_recovered" if loss else "cdsp_original")
    assert "cdsp_original" not in output and "cdsu_original" not in output


@pytest.mark.parametrize("status,state", [(401, ""), (503, ""), (200, "unknown"), (200, "credential-unusable")])
def test_unusable_saved_identity_never_downgrades_to_anonymous(workspace, monkeypatch, status, state):
    monkeypatch.setattr(cdscli, "_load_user_credential", lambda host: "cdsu_expired")
    calls = []
    def fake_request(method, url, **kwargs):
        calls.append((method, url))
        return status, {"state": state}, {}
    monkeypatch.setattr(cdscli, "_request", fake_request)
    code, output = run_command(["connect", "--host", "cds.example", "--project", "p"])
    assert code == 2
    assert calls == [("GET", "/api/projects/p/access-status")]
    assert not (workspace / ".cds/credentials.json").exists()


def test_suspended_ticket_waits_without_creating_another_approval(workspace, monkeypatch):
    monkeypatch.setattr(cdscli, "_load_user_credential", lambda host: "")
    states = iter([{"status": "blocked", "message": "等待管理员恢复原账号"},
                   {"status": "approved", "authorizationKey": "cdsp_after_restore"}])
    posts = []
    def fake_request(method, url, **kwargs):
        if method == "POST":
            posts.append(url)
            return 201, {"requestId": "r", "pollToken": "poll"}, {}
        if url.endswith("/r"):
            return 200, next(states), {}
        return 200, {"id": "p"}, {}
    monkeypatch.setattr(cdscli, "_request", fake_request)
    monkeypatch.setattr(cdscli.time, "sleep", lambda _: None)
    code, output = run_command(["connect", "--host", "cds.example", "--project", "p"])
    assert code == 0, output
    assert posts == ["/api/projects/p/access-requests"]
    assert "cdsp_after_restore" not in output


def test_rejected_connect_does_not_write_credentials(workspace, monkeypatch):
    def fake_request(method, path, body=None, timeout=15, extra_headers=None,
                     fatal_network_errors=True):
        if method == "POST":
            return 201, {"requestId": "req3", "pollToken": "poll3"}, {}
        return 200, {"status": "rejected", "rejectReason": "测试拒绝"}, {}

    monkeypatch.setattr(cdscli, "_request", fake_request)
    monkeypatch.setattr(cdscli.time, "sleep", lambda _seconds: None)
    code, output = run_command([
        "connect", "--host", "cds.example", "--project", "proj-a",
    ])

    assert code == 2
    assert "测试拒绝" in output
    assert not (workspace / ".cds" / "credentials.json").exists()


def test_connect_keeps_waiting_after_transient_poll_timeout(workspace, monkeypatch):
    secret = "cdsp_after-timeout"
    poll_count = 0

    def fake_request(method, path, body=None, timeout=15, extra_headers=None,
                     fatal_network_errors=True):
        nonlocal poll_count
        if method == "POST":
            return 201, {"requestId": "req-timeout", "pollToken": "poll-timeout"}, {}
        if path.endswith("/req-timeout"):
            assert fatal_network_errors is False
            poll_count += 1
            if poll_count == 1:
                return 0, {"error": "timeout", "message": "timeout=10s"}, {}
            return 200, {"status": "approved", "authorizationKey": secret}, {}
        return 200, {"id": "proj-a"}, {}

    monkeypatch.setattr(cdscli, "_request", fake_request)
    monkeypatch.setattr(cdscli.time, "sleep", lambda _seconds: None)

    code, output = run_command([
        "connect", "--host", "https://cds.example", "--project", "proj-a",
        "--agent", "Codex", "--interval", "1",
    ])

    assert code == 0
    assert poll_count == 2
    assert secret not in output
    saved = json.loads((workspace / ".cds" / "credentials.json").read_text())
    assert saved["projectKey"] == secret


def test_project_create_switches_from_bootstrap_to_project_key(workspace, monkeypatch):
    bootstrap = "cdsg_one-time"
    project_key = "cdsp_new-project"
    cdscli._save_local_credentials(host="https://cds.example", bootstrap_key=bootstrap)
    os.environ["CDS_HOST"] = "https://cds.example"
    os.environ["AI_ACCESS_KEY"] = bootstrap
    monkeypatch.setattr(cdscli, "_call", lambda *args, **kwargs: {
        "project": {"id": "proj-new", "slug": "new", "name": "New"},
        "issuedProjectKey": {"keyId": "k1", "plaintext": project_key},
    })
    # 换钥后会用新 key 回读一次项目（自证钥匙真能用），这一跳走 _request。
    monkeypatch.setattr(cdscli, "_request",
                        lambda *args, **kwargs: (200, {"id": "proj-new"}, {}))

    code, output = run_command(["project", "create", "--name", "New"])

    assert code == 0
    assert project_key not in output
    saved = json.loads((workspace / ".cds" / "credentials.json").read_text())
    assert saved["projectId"] == "proj-new"
    assert saved["projectKey"] == project_key
    assert "bootstrapKey" not in saved


def test_auth_inspect_strict_accepts_identical_workspace_and_environment_credentials(workspace, monkeypatch):
    secret = "cdsp_same-project-key"
    cdscli._save_local_credentials(
        host="https://cds.example",
        project_id="proj-a",
        project_key=secret,
    )
    monkeypatch.setenv("CDS_HOST", "cds.example")
    monkeypatch.setenv("CDS_PROJECT_ID", "proj-a")
    monkeypatch.setenv("CDS_PROJECT_KEY", secret)
    monkeypatch.setattr(cdscli, "_EXPLICIT_CREDENTIAL_ENV", {
        "CDS_HOST": "cds.example",
        "CDS_PROJECT_ID": "proj-a",
        "CDS_PROJECT_KEY": secret,
        "AI_ACCESS_KEY": "",
    })

    code, output = run_command(["auth", "inspect", "--strict"])

    assert code == 0, output
    payload = json.loads(output.strip().split("\n")[-1])
    assert payload["data"]["conflicts"] == []
    assert secret not in output


def test_auth_inspect_strict_rejects_different_workspace_and_environment_keys(workspace, monkeypatch):
    cdscli._save_local_credentials(
        host="https://cds.example",
        project_id="proj-a",
        project_key="cdsp_workspace-key",
    )
    monkeypatch.setenv("CDS_HOST", "https://cds.example")
    monkeypatch.setenv("CDS_PROJECT_ID", "proj-a")
    monkeypatch.setenv("CDS_PROJECT_KEY", "cdsp_other-key")
    monkeypatch.setattr(cdscli, "_EXPLICIT_CREDENTIAL_ENV", {
        "CDS_HOST": "https://cds.example",
        "CDS_PROJECT_ID": "proj-a",
        "CDS_PROJECT_KEY": "cdsp_other-key",
        "AI_ACCESS_KEY": "",
    })

    code, output = run_command(["auth", "inspect", "--strict"])

    assert code == 2
    payload = json.loads(output.strip().split("\n")[-1])
    assert payload["credentialSummary"]["conflicts"] == ["projectKeySource"]
    assert "cdsp_workspace-key" not in output
    assert "cdsp_other-key" not in output


def test_declared_origin_does_not_send_embedded_credentials():
    assert cdscli._safe_repository_url("https://user:secret@github.com/acme/demo.git?token=secret#x") == "https://github.com/acme/demo.git"
    assert cdscli._safe_repository_url("git@github.com:acme/demo.git") == "git@github.com:acme/demo.git"


@pytest.mark.parametrize("change", [{"name": "Second"}, {"slug": "second"}, {"repository": "https://github.com/example/second"}])
def test_explicit_different_creation_target_is_not_silently_reused(workspace, monkeypatch, change):
    subprocess.run(["git", "remote", "add", "origin", "https://github.com/example/demo"], check=True)
    cdscli._save_local_credentials(host="https://cds.example", project_id="p", project_key="cdsp_keep",
                                   project_name="Demo", project_slug="demo")
    calls = []
    def request(method, path, body=None, **kwargs):
        calls.append((method, path))
        if path == "/api/bootstrap-access-requests":
            assert body["requestedProject"]["name"] == change.get("name", "Demo")
            return 201, {"requestId": "r", "pollToken": "poll"}, {}
        if path.endswith("/r"):
            return 200, {"status": "rejected", "rejectReason": "fixture"}, {}
        raise AssertionError("新目标不能复用原项目")
    monkeypatch.setattr(cdscli, "_request", request)
    args = ["connect", "--host", "cds.example", "--new-project", "--create-project", change.get("name", "Demo")]
    if change.get("slug"): args += ["--slug", change["slug"]]
    if change.get("repository"): args += ["--git-url", change["repository"]]
    code, output = run_command(args)
    assert code == 2 and "fixture" in output
    assert json.loads((workspace / ".cds/credentials.json").read_text())["projectKey"] == "cdsp_keep"
    assert "cdsp_keep" not in output


def test_legacy_context_name_is_learned_without_new_approval(workspace, monkeypatch):
    subprocess.run(["git", "remote", "add", "origin", "https://github.com/example/demo"], check=True)
    cdscli._save_local_credentials(host="https://cds.example", project_id="p", project_key="cdsp_keep")
    def request(method, path, **kwargs):
        assert method == "GET" and path == "/api/projects/p"
        return 200, {"id": "p", "name": "Demo", "slug": "demo"}, {}
    monkeypatch.setattr(cdscli, "_request", request)
    code, output = run_command(["connect", "--host", "cds.example", "--new-project", "--create-project", "Demo"])
    assert code == 0, output
    assert json.loads((workspace / ".cds/connection.json").read_text())["projectName"] == "Demo"


def test_display_rename_keeps_original_creation_command_reusable(workspace, monkeypatch):
    subprocess.run(["git", "remote", "add", "origin", "https://github.com/example/demo"], check=True)
    cdscli._save_local_credentials(host="https://cds.example", project_id="p", project_key="cdsp_keep", project_name="Demo", project_slug="demo")
    def request(method, path, **kwargs):
        assert method == "GET" and path == "/api/projects/p"
        return 200, {"id": "p", "name": "Renamed", "slug": "renamed"}, {}
    monkeypatch.setattr(cdscli, "_request", request)
    args = ["connect", "--host", "cds.example", "--new-project", "--create-project", "Demo", "--slug", "Demo"]
    for _ in range(2):
        code, output = run_command(args)
        assert code == 0, output
    context = json.loads((workspace / ".cds/connection.json").read_text())
    assert context["projectName"] == "Renamed" and context["creationName"] == "Demo"
    assert context["creationSlug"] == "demo"

@pytest.mark.parametrize('explicit', [True, False])
def test_original_identity_recovery_saves_both_credentials_without_user_input(workspace, monkeypatch, explicit):
    monkeypatch.setattr(cdscli, '_USER_CREDENTIALS_PATH', str(workspace / 'private/user.json'))
    monkeypatch.setattr(cdscli, '_origin_repository', lambda: 'git@github.com:example/original.git')
    monkeypatch.setattr(cdscli.time, 'sleep', lambda _: None)
    calls = []
    def request(method, path, body=None, **kwargs):
        calls.append((method, path))
        if path == '/api/identity-connections':
            assert body['repository'] == 'git@github.com:example/original.git'
            return 201, {'requestId': 'ic_test', 'pollToken': 'ticket-secret'}, {}
        if path.endswith('/ack'):
            assert (workspace / '.cds/credentials.json').exists()
            assert (workspace / 'private/user.json').exists()
            return 200, {'delivered': True}, {}
        if path == '/api/identity-connections/ic_test':
            return 200, {'status': 'approved', 'projectId': 'project-a', 'projectName': '原项目', 'projectSlug': 'original', 'authorizationKey': 'cdsp_original_secret', 'userCredential': 'cdsu_original_secret'}, {}
        return 200, {'id': 'project-a'}, {}
    monkeypatch.setattr(cdscli, '_request', request)
    code, output = run_command(['connect', '--host', 'https://cds.example'] + (['--recover'] if explicit else ['--project', 'project-a']))
    assert code == 0
    assert 'cdsu_original_secret' not in output and 'cdsp_original_secret' not in output and 'ticket-secret' not in output
    assert cdscli._load_user_credential('https://cds.example') == 'cdsu_original_secret'
    assert json.loads((workspace / '.cds/credentials.json').read_text())['projectId'] == 'project-a'
    assert (workspace / '.cds/credentials.json').stat().st_mode & 0o777 == 0o600
    assert not (workspace / '.cds/identity-recovery.json').exists()
    assert all('/projects' != p for _, p in calls)
    assert calls[-1] == ('POST', '/api/identity-connections/ic_test/ack')


def test_identity_recovery_keeps_ticket_until_both_files_saved_and_resumes_without_reapproval(workspace, monkeypatch):
    monkeypatch.setattr(cdscli, '_USER_CREDENTIALS_PATH', str(workspace / 'private/user.json'))
    monkeypatch.setattr(cdscli, '_origin_repository', lambda: 'https://github.com/example/original')
    calls = []
    def request(method, path, **kwargs):
        calls.append((method, path))
        if path == '/api/identity-connections':
            return 201, {'requestId': 'ic_resume', 'pollToken': 'private-ticket'}, {}
        if path.endswith('/ack'): return 200, {'delivered': True}, {}
        if path == '/api/identity-connections/ic_resume':
            return 200, {'status': 'approved', 'projectId': 'project-a', 'authorizationKey': 'cdsp_saved_key', 'userCredential': 'cdsu_saved_identity'}, {}
        return 200, {'id': 'project-a'}, {}
    monkeypatch.setattr(cdscli, '_request', request)
    save = cdscli._save_local_credentials
    def fail(**kwargs): raise OSError('synthetic disk full')
    monkeypatch.setattr(cdscli, '_save_local_credentials', fail)
    with pytest.raises(OSError): run_command(['connect', '--host', 'https://cds.example', '--recover'])
    ticket = workspace / '.cds/identity-recovery.json'
    assert ticket.stat().st_mode & 0o777 == 0o600
    assert subprocess.run(['git', 'check-ignore', '-q', '.cds/identity-recovery.json']).returncode == 0
    assert not any(p.endswith('/ack') for _, p in calls)
    monkeypatch.setattr(cdscli, '_save_local_credentials', save)
    code, output = run_command(['connect', '--host', 'https://cds.example', '--recover'])
    assert code == 0 and 'private-ticket' not in output
    assert sum(p == '/api/identity-connections' for _, p in calls) == 1
    assert not ticket.exists()


def test_original_identity_recovery_rejects_wrong_project_without_saving(workspace, monkeypatch):
    monkeypatch.setattr(cdscli, '_USER_CREDENTIALS_PATH', str(workspace / 'private/user.json'))
    monkeypatch.setattr(cdscli, '_origin_repository', lambda: 'https://github.com/example/original')
    def request(method, path, **kwargs):
        if method == 'POST': return 201, {'requestId': 'ic_test', 'pollToken': 'secret-ticket'}, {}
        return 200, {'status': 'approved', 'projectId': 'other', 'authorizationKey': 'cdsp_other', 'userCredential': 'cdsu_other'}, {}
    monkeypatch.setattr(cdscli, '_request', request)
    code, _ = run_command(['connect', '--host', 'https://cds.example', '--project', 'project-a'])
    assert code == 2
    assert not (workspace / '.cds/credentials.json').exists()
    assert not (workspace / 'private/user.json').exists()


def test_identity_recovery_ack_response_loss_reuses_saved_pair_on_next_process(workspace, monkeypatch):
    monkeypatch.setattr(cdscli, '_USER_CREDENTIALS_PATH', str(workspace / 'private/user.json'))
    monkeypatch.setattr(cdscli, '_origin_repository', lambda: 'https://github.com/example/original')
    calls = []; delivered = False
    def request(method, path, **kwargs):
        nonlocal delivered
        calls.append((method, path))
        if path == '/api/identity-connections': return 201, {'requestId': 'ic_ack', 'pollToken': 'ack-secret'}, {}
        if path.endswith('/ack'):
            delivered = True
            return 0, None, {}
        if path == '/api/identity-connections/ic_ack':
            if delivered: return 200, {'status': 'delivered'}, {}
            return 200, {'status': 'approved', 'projectId': 'project-a', 'authorizationKey': 'cdsp_ack_key', 'userCredential': 'cdsu_ack_user'}, {}
        return 200, {'id': 'project-a'}, {}
    monkeypatch.setattr(cdscli, '_request', request)
    argv = ['connect', '--host', 'https://cds.example', '--recover']
    assert run_command(argv)[0] == 0
    assert (workspace / '.cds/identity-recovery.json').exists()
    code, output = run_command(argv)
    assert code == 0 and json.loads(output)['data']['reused'] is True
    assert calls.count(('POST', '/api/identity-connections')) == 1
    assert not (workspace / '.cds/identity-recovery.json').exists()
    assert calls[-1] == ('GET', '/api/projects/project-a')


def test_identity_recovery_accepts_original_slug_and_saves_canonical_id(workspace, monkeypatch):
    monkeypatch.setattr(cdscli, '_USER_CREDENTIALS_PATH', str(workspace / 'private/user.json'))
    monkeypatch.setattr(cdscli, '_origin_repository', lambda: 'https://github.com/example/original')
    def request(method, path, **kwargs):
        if path == '/api/identity-connections': return 201, {'requestId': 'ic_slug', 'pollToken': 'slug-secret'}, {}
        if path.endswith('/ack'): return 200, {'delivered': True}, {}
        if path == '/api/identity-connections/ic_slug':
            return 200, {'status': 'approved', 'projectId': 'canonical-id', 'projectSlug': 'original-slug', 'authorizationKey': 'cdsp_slug_key', 'userCredential': 'cdsu_slug_user'}, {}
        return 200, {'project': {'id': 'canonical-id', 'slug': 'original-slug'}}, {}
    monkeypatch.setattr(cdscli, '_request', request)
    assert run_command(['connect', '--host', 'https://cds.example', '--project', 'original-slug'])[0] == 0
    assert json.loads((workspace / '.cds/credentials.json').read_text())['projectId'] == 'canonical-id'


def test_recovery_ticket_is_private_while_writing_and_failure_leaves_no_secret_fragment(workspace, monkeypatch):
    monkeypatch.setattr(cdscli, '_origin_repository', lambda: 'https://github.com/example/original')
    def request(*args, **kwargs): return 201, {'requestId': 'ic_private', 'pollToken': 'private-ticket'}, {}
    monkeypatch.setattr(cdscli, '_request', request)
    def failing_dump(data, stream, **kwargs):
        assert os.fstat(stream.fileno()).st_mode & 0o777 == 0o600
        relative = str(Path(stream.name).relative_to(workspace)) if isinstance(stream.name, str) else None
        if relative: assert subprocess.run(['git', 'check-ignore', '-q', relative]).returncode == 0
        stream.write('private-ticket')
        raise OSError('synthetic interrupted write')
    monkeypatch.setattr(cdscli.json, 'dump', failing_dump)
    with pytest.raises(OSError): run_command(['connect', '--host', 'https://cds.example', '--recover'])
    assert not list((workspace / '.cds').glob('*.tmp'))
    assert not (workspace / '.cds/identity-recovery.json').exists()


@pytest.mark.parametrize("interrupt", [False, True])
def test_bootstrap_wait_timeout_or_interrupt_cancels_only_own_request(workspace, monkeypatch, interrupt):
    subprocess.run(["git", "remote", "add", "origin", "https://github.com/example/demo.git"], check=True)
    calls = []
    ticks = [0]
    monkeypatch.setattr(cdscli.time, "monotonic", lambda: ticks[0])
    def sleep(_seconds):
        if interrupt:
            raise KeyboardInterrupt()
        ticks[0] += 12
    monkeypatch.setattr(cdscli.time, "sleep", sleep)
    def fake_request(method, path, body=None, extra_headers=None, **kwargs):
        calls.append((method, path, extra_headers))
        if method == "POST":
            assert body["waitSeconds"] == 10
            return 201, {"requestId": "r", "pollToken": "poll"}, {}
        assert extra_headers == {"X-Poll-Token": "poll"}
        return 200, {"status": "pending"}, {}
    monkeypatch.setattr(cdscli, "_request", fake_request)
    argv = ["connect", "--host", "https://cds.example", "--new-project", "--create-project", "demo", "--timeout", "10"]
    if interrupt:
        with pytest.raises(KeyboardInterrupt):
            run_command(argv)
    else:
        code, output = run_command(argv)
        assert code == 2
        assert "poll" not in output
    assert calls[-1] == ("DELETE", "/api/bootstrap-access-requests/r", {"X-Poll-Token": "poll"})
    assert not (workspace / ".cds/credentials.json").exists()
