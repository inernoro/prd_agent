import fs from 'node:fs';
import path from 'node:path';
import crypto from 'node:crypto';
import {calibrate,compare,digest,executionErrors} from '../../e2e/performance/metrics.mjs';
const here=path.dirname(new URL(import.meta.url).pathname),root=path.join(here,'artifacts');
const read=n=>JSON.parse(fs.readFileSync(path.join(root,n)));
const baseline=read('baseline.json'),bases=[1,2,3].map(n=>read(`base-${n}/result.json`));
const recalibrated=calibrate(bases);
if(digest(baseline)!==digest(recalibrated))throw Error('归档基线不能由三次原始结果精确重算');
if(baseline.commit!=='49b8e320f8c194dd92490e4623635c05f463fcec')throw Error('基准SHA发生变化');
const candidate=read('candidate/result.json');
if(candidate.commit!=='f8fd1280c7e7d01b45ca350c6c2f1757e35fb07c'||candidate.execution.profile!=='all')throw Error('修复SHA或all档位不符');
const results={};for(const n of ['candidate','injected','injected-browser','recovered']){
 try{const r=read(n+'/result.json');results[n]={commit:r.commit,execution:r.execution,executionErrors:executionErrors(r),stored:r.comparison,recomputed:compare(r,baseline)};}
 catch(e){results[n]={error:e.message};}
}
const capacity=candidate.capacity;
const resourcePeaks=Object.fromEntries(['api','mongo','redis','web'].map(role=>{
 const rows=candidate.resources.flatMap(t=>t.samples).filter(s=>s.role===role);
 return [role,{cpuPercent:Math.max(...rows.map(s=>s.cpuPercent??0)),rssMiB:Math.max(...rows.map(s=>s.rssBytes))/2**20}];
}));
let pages;try{const r=read('local-acceptance/result.json');pages={commit:r.commit,pass:r.pass,state:r.state,cases:r.cases.map(c=>({id:c.id,pass:c.pass,persisted:c.persisted,layout:c.layout})),anonymous:r.anonymous,restartRecovery:r.restartRecovery,identity:r.buildIdentity};}catch(e){pages={error:e.message};}
const normal=candidate.phases.find(p=>p.name==='normal'),soak=candidate.phases.find(p=>p.name==='soak');
const phases=candidate.phases.map(p=>({name:p.name,users:p.users,seconds:p.seconds,journey:p.metrics.journey}));
const review={runId:43821630330,runUrl:'https://github.com/inernoro/prd_agent/actions/runs/43821630330',event:'workflow_dispatch',baselineRecalibratedExactly:true,baselineCommit:baseline.commit,repairCommit:candidate.commit,phases,capacity,resourcePeaks,resourceAccounting:candidate.resourceAccounting,actualCgroups:candidate.contract.effectiveCgroups,buildIdentity:candidate.buildIdentity,browserSamples:candidate.browser.samples,results,pages,pass:results.candidate.recomputed?.pass===true&&results.injected.recomputed?.pass===false&&results['injected-browser'].recomputed?.pass===false&&results.recovered.recomputed?.pass===true&&pages.pass===true};
fs.writeFileSync(path.join(here,'independent-review.json'),JSON.stringify(review,null,2));
console.log(JSON.stringify(review,null,2));if(!review.pass)process.exitCode=1;
