import subprocess,os,json,time,pathlib
root=pathlib.Path('/workspace/prd_agent/work/independent-1997/runner')
env=os.environ.copy();env.update(DOTNET_BIN='/workspace/prd_agent/work/dotnet8/dotnet',PERF_CHROMIUM_PATH='/usr/bin/chromium')
out=root/'work/independent';base='49b8e320f8c194dd92490e4623635c05f463fcec';candidate='c97ab1d2ca3147ae3e81d483a21fdb84b50f0d1e'
def execute(name,args):
 with open(root.parent/(name+'.log'),'w') as log:
  status=subprocess.run(args,cwd=root,env=env,stdout=log,stderr=subprocess.STDOUT).returncode
 print(name,status,flush=True)
 with open(root.parent/'statuses.ndjson','a') as f:f.write(json.dumps({'name':name,'status':status,'at':time.time()})+'\n')
 return status
def run(name,ref,profile='normal',extra=[]):return execute(name,['node','e2e/performance/run.mjs','--ref',ref,'--profile',profile,'--out','work/independent/'+name]+extra)
# Wait for the already launched baseline, including its real terminal state.
while True:
 try:
  r=json.loads((out/'base-1/result.json').read_text())
  if r.get('finishedAt'):break
 except (FileNotFoundError,json.JSONDecodeError):pass
 time.sleep(2)
if r.get('failure'):print('base-1 failed; blocked calibration',flush=True);raise SystemExit(1)
for n in [2,3]:
 if run('base-'+str(n),base):raise SystemExit(1)
if execute('calibration',['node','e2e/performance/calibrate.mjs',*[str(out/('base-'+str(n))/'result.json') for n in [1,2,3]],'--out',str(out/'baseline.json')]):raise SystemExit(1)
compare=['--baseline','work/independent/baseline.json']
run('candidate',candidate,'all',compare)
execute('write-proof',['node','e2e/performance/prove-write.mjs','work/independent/candidate'])
run('injected-app',candidate,extra=compare+['--inject-ms','350'])
execute('app-proof',['node','e2e/performance/prove.mjs','work/independent/injected-app/result.json'])
run('injected-browser',candidate,extra=compare+['--inject-browser-ms','10000'])
execute('browser-proof',['node','e2e/performance/prove-browser.mjs','work/independent/injected-browser/result.json'])
run('recovered',candidate,extra=compare)
execute('pages',['node','e2e/performance/local-acceptance.mjs','--prepared','work/independent/recovered/result.json','--out','work/independent/pages'])
for name in ['candidate','injected-app','injected-browser','recovered']:
 execute('report-'+name,['node','e2e/performance/report.mjs',str(out/name/'result.json'),str(out/'baseline.json'),'--out',str(out/'reports'/(name+'.html'))])
