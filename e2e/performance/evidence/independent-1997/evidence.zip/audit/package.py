import pathlib,json,shutil,hashlib,zipfile,html,subprocess
here=pathlib.Path('/workspace/prd_agent/work/independent-1997'); data=here/'runner/work/independent'
out=here/'bundle';out.mkdir(parents=True,exist_ok=True)
def read(n):return json.loads((data/n).read_text())
r=read('candidate/result.json'); b=read('baseline.json'); app=read('injected-app/result.json'); browser=read('injected-browser/result.json'); recovery=read('recovered/result.json'); pages=read('pages/result.json');fix=read('guard-fix-proof.json');contrast=read('old-new-real-negative.json')
assert pages['pass'] and recovery['comparison']['pass'] and not app['comparison']['pass'] and not browser['comparison']['pass']
commit=subprocess.check_output(['git','rev-parse','HEAD'],cwd=here/'fix',text=True).strip()
summary={'candidate':r['commit'],'baseline':b['commit'],'fixCommit':commit,'candidateComparison':r['comparison'],'recovery':recovery['comparison'],'pages':pages['pass'],'capacity':r['capacity'],'cloudRun':'43722741724','cloudArtifactRead':'PASS: GitHub connector downloaded ZIP; SHA256 matches upload; proofs rerun','publicPreview':'NOT_ACCEPTED: later SHA 6622fc5d5dd355fbe97d8f5de2f3ead1539fa76e','overallCandidate':'FAIL: missing API baseline / sparse app timing accepted by original judge','phaseMetrics':{},'resourcePeaks':{}}
for p in r['phases']:
 summary['phaseMetrics'][p['name']]={'journey':p['metrics']['journey'],'scenarios':p['metrics']}
for role in ['api','mongo','redis','web']:
 rows=[s for t in r['resources'] for s in t['samples'] if s['role']==role]
 summary['resourcePeaks'][role]={'cpuPercent':max(s['cpuPercent'] or 0 for s in rows),'rssMiB':max(s['rssBytes'] for s in rows)/2**20}
(out/'summary.json').write_text(json.dumps(summary,ensure_ascii=False,indent=2))
# Explicit allowlist: do not package builds, runtime settings, API directories or credentials.
files=[]
for p in data.rglob('*'):
 if p.is_file() and (p.suffix in ['.json','.ndjson','.png','.html'] or p.name.endswith('-build.log')):files.append((p,pathlib.Path('measurements')/p.relative_to(data)))
for p in here.iterdir():
 if p.is_file() and p.suffix in ['.log','.json','.txt','.ndjson','.py','.mjs']:files.append((p,pathlib.Path('audit')/p.name))
# Cloud ZIP retained separately; its original artifact URL and verified SHA are in ci-independent-review.json.
patch=subprocess.check_output(['git','diff','c97ab1d2ca3147ae3e81d483a21fdb84b50f0d1e','HEAD'],cwd=here/'fix')
(out/'judge-fix.patch').write_bytes(patch)
manifest=[]
with zipfile.ZipFile(out/'evidence.zip','w',zipfile.ZIP_DEFLATED) as z:
 for p,name in sorted(files,key=lambda x:str(x[1])):
  raw=p.read_bytes();z.writestr(str(name),raw);manifest.append({'file':str(name),'sha256':hashlib.sha256(raw).hexdigest(),'bytes':len(raw)})
 z.writestr('manifest.json',json.dumps(manifest,ensure_ascii=False,indent=2))
(out/'manifest.json').write_text(json.dumps(manifest,ensure_ascii=False,indent=2))
shots=out/'screenshots';shots.mkdir(exist_ok=True)
for src in (data/'pages').glob('*.png'):shutil.copy2(src,shots/src.name)
for name in ['candidate','injected-app','injected-browser','recovered','running']:
 src=data/'reports'/f'{name}.html'
 if src.exists():shutil.copy2(src,out/(name+'.html'))
for name in ['report-desktop.png','report-mobile.png','report-homepage-slow.png']:
 src=data/'reports'/name
 if src.exists():shutil.copy2(src,shots/name)
esc=lambda v:html.escape(str(v))
normal=r['phases'][0]['metrics']['journey'];soak=r['phases'][-1]['metrics']['journey']
pageNames={'home':'登录后首页','knowledge-list':'知识库列表','document-open':'打开文档','write':'保存与刷新'}
pathrows=''.join(f'<tr><td>{pageNames[n]}</td><td>{max(r["browser"]["samples"][n])/1000:.3f} 秒</td><td>{b["browserLimits"][n]["readyP95Ms"]/1000:.3f} 秒</td></tr>' for n in pageNames)
loadrows=''.join(f'<tr><td>{esc(p["name"])}</td><td>{p["users"]}</td><td>{p["metrics"]["journey"]["attempts"]}</td><td>{p["metrics"]["journey"]["client"]["p95"]:.2f}</td><td>{p["metrics"]["journey"]["client"]["p99"]:.2f}</td><td>{p["metrics"]["journey"]["errors"]}</td><td>{p["metrics"]["journey"]["throughput"]:.2f}</td></tr>' for p in r['phases'])
resrows=''.join(f'<tr><td>{role}</td><td>{v["cpuPercent"]:.1f}%</td><td>{v["rssMiB"]:.1f} MiB</td></tr>' for role,v in summary['resourcePeaks'].items())
statuses=[('正常负载','通过','120组零错误，p95 124.17ms，实测同机门槛241.10ms。'),('并发增长','通过探测；存在容量退化','2/4/8/16/32/64/128均执行；8并发版本历史首次超过正常两倍。吞吐在约90–101组/秒平台，128并发p95 1874ms。'),('持续运行','通过（120秒）','240组零错误，p95 116.31ms；不能证明小时级稳定。'),('后台350ms识别','通过','业务完成且零错误；运行退出1，证明器退出0，文档打开app p95 365.10ms > 51.10ms；外部HTTP为零。'),('首页10秒交付识别','通过',f'三个上下文命中真实首页脚本；页面业务完成；首页{max(browser["browser"]["samples"]["home"])/1000:.3f}秒，门槛2.601秒；全部API门禁正常。运行退出1、证明器退出0。'),('同一真实负例旧新对照','通过','旧47e71839d判定通过，候选与修复版均拒绝；原始负例与基线哈希固定。'),('撤除故障恢复','通过',f'全新候选实例，{recovery["phases"][0]["metrics"]["journey"]["attempts"]}组零错误，原基线门禁通过。'),('重复性与提交比较','通过','三次独立基准，每次120组，p95 66.59/93.66/110.22ms；API编译/声明/Web SHA均核对；候选未混入基线。'),('中断/契约/缺样本防误放行','原候选失败；独立分支已修复','真实运行快照已拒绝；但原比较器接受缺API基线或应用计时仅1样本，已保留两个失败测试。修复版24项测试通过，同份实测数据派生的反例旧通过、新拒绝，正常及两类退化判定保持正确。修复尚未合并。'),('GitHub自动运行','通过（normal）','push事件，固定候选与基准正确，三基准、候选、两个负例、恢复、本地页面、中文摘要、上传均实际成功；不是all。独立Preview/E2E和Smoke作业跳过。'),('云端归档内容复核','通过','139文件、49,052,011字节，ZIP SHA256与上传记录一致；已读取原始结果、4份HTML和101张截图清单，重新执行两类证明器与写入核验通过。最初隧道403已由GitHub连接器下载解决。'),('真实本地页面','通过','桌面1440×1000、手机390×844，明暗主题四场景均从公共入口真实登录，经首页/知识库/文档编辑保存刷新；唯一正文标记可见、独立回读一致；匿名401且正文未变，真实API重启恢复通过。'),('公开预览','未验收','preview-url取得真实main入口，GET可达，但API已是后续6622fc5…，Web入口后缀local；未向其压测或写入，未替换验收对象。')]
statusrows=''.join(f'<tr><td>{esc(a)}</td><td>{esc(s)}</td><td>{esc(d)}</td></tr>' for a,s,d in statuses)
page=f'''<!doctype html><html lang="zh-CN"><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>MAP 独立性能验收</title><style>body{{font:16px/1.7 system-ui,sans-serif;color:#20262c;background:#f5f5f1;margin:0}}main{{max-width:1100px;margin:32px auto;padding:0 20px}}section{{background:white;border:1px solid #ddd;border-radius:12px;padding:22px;margin:20px 0}}.verdict{{background:#fff0e8;border-color:#b56d40}}h1{{font-size:30px}}h2{{font-size:23px}}table{{width:100%;border-collapse:collapse}}th,td{{text-align:left;padding:10px;border-bottom:1px solid #ddd;vertical-align:top}}code{{overflow-wrap:anywhere}}.scroll{{overflow-x:auto}}a{{color:#245ca6}}img{{max-width:100%;border:1px solid #ddd}}@media(max-width:600px){{td,th{{padding:6px;font-size:14px}}main{{padding:0 10px}}section{{padding:14px}}}}</style><main><h1>MAP 独立性能验收</h1><section class="verdict"><h2>原候选整体未通过：发现两项门禁误放行缺陷</h2><p>已实测证明能自动识别后台延迟和“接口快、页面慢”，正常与短持续负载通过；但原比较器对缺失API基线、应用计时样本不足存在误放行。修复已在独立分支完成，未再次合并、未发布生产。公开候选预览仍未验收；云端归档已独立复核。</p><p>正常可见页面三次中的最慢：首页1.12秒、列表0.21秒、文档1.84秒、保存刷新1.29秒。容量边界从8并发开始，吞吐平台约90–101组/秒；仅适用于本次共享4核/16GiB、248篇文档、单管理员、无模型的隔离环境。</p></section><section><h2>固定验收对象</h2><p>候选：<code>{r['commit']}</code><br>基准：<code>{b['commit']}</code><br>修复：<code>{commit}</code>，分支 audit/map-performance-1997。候选已进入main；后续main变化未替换对象。</p><p>先冻结断言，后采集三次基准，再运行候选all及两类受控故障、撤除恢复和真实页面。历史报告未用于本轮阈值。</p></section><section><h2>逐项结论</h2><div class="scroll"><table><tr><th>项目</th><th>结果</th><th>判断依据</th></tr>{statusrows}</table></div></section><section><h2>真实页面等待时间</h2><table><tr><th>操作</th><th>三次中的最慢</th><th>本轮基准门槛</th></tr>{pathrows}</table><p>浏览器每步只有3个样本，用于早期退化预警，不能承诺生产SLO。API整组耗时与完整页面耗时是不同指标。</p></section><section><h2>实际负载结果</h2><div class="scroll"><table><tr><th>阶段</th><th>并发</th><th>组数</th><th>p95 ms</th><th>p99 ms</th><th>错误</th><th>成功组/秒</th></tr>{loadrows}</table></div></section><section><h2>资源与适用范围</h2><table><tr><th>部分</th><th>各自峰值CPU</th><th>各自峰值RSS</th></tr>{resrows}</table><p>100%为一核；RSS为进程树相加，可能重复包含共享页，不是PSS。四容器实际读取cpu.max均为400000 100000、memory.max均为17179869184，共享同一4核/16GiB宿主cgroup。声明的API 1核/1GiB、Mongo 1核/768MiB等没有实施；不能将本容量套到这些硬配额。单账号临时限流100000请求/分钟、1024并发；默认账号配额不能据此承诺。外部HTTP时间为零，应用时间包含数据库、Redis和排队。</p><p>未覆盖生产数据分布、普通角色矩阵、所有真机浏览器与小时级运行。全部压力仅作用于本地临时隔离网络，无付费模型调用、无资源购买、无生产写入或发布。</p></section><section><h2>可见证据</h2><p><a href="screenshots/desktop-dark-saved-refresh.png">桌面深色保存刷新</a> · <a href="screenshots/desktop-light-saved-refresh.png">桌面浅色</a> · <a href="screenshots/mobile-dark-saved-refresh.png">手机深色</a> · <a href="screenshots/mobile-light-server-restart.png">手机浅色API重启恢复</a></p><p><a href="candidate.html">候选原版可读报告</a> · <a href="injected-browser.html">首页慢的可读失败报告</a> · <a href="injected-app.html">后台慢的可读失败报告</a> · <a href="running.html">运行中不得通过</a> · <a href="recovered.html">新实例恢复</a></p><p><a href="https://github.com/inernoro/prd_agent/actions/runs/43722741724">GitHub最终运行</a> · <a href="https://github.com/inernoro/prd_agent/actions/runs/43722741724/artifacts/14165967804">云端原始归档（已校验）</a> · <a href="evidence.zip">全部独立原始证据与哈希清单</a> · <a href="judge-fix.patch">独立修复补丁</a></p><p>候选原版报告中的“通过”只表示该正常/持续性能比较通过，不能覆盖本独立验收发现的防误放行缺陷。所有原始失败记录均保留。</p></section></main></html>'''
(out/'acceptance.html').write_text(page)
print(json.dumps(summary,ensure_ascii=False,indent=2)[:2000]);print('packaged',len(files),'files',out)
